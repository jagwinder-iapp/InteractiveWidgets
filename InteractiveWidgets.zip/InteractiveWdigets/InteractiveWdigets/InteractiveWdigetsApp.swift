//
//  InteractiveWdigetsApp.swift
//  InteractiveWdigets
//
//  Created by Iapp on 20/06/23.
//

import SwiftUI

@main
struct InteractiveWdigetsApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
